import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-updatebook',
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdatebookComponent{

  book:Book;
  bookid:any;
  bookname:any;
  bookauthor:any;
  bookdao:BookdaoService;
  constructor(bookdao:BookdaoService,private activatedRoute:ActivatedRoute,private router:Router){
    this.bookdao = bookdao;
    this.bookid = this.activatedRoute.snapshot.paramMap.get('id');
    this.bookname = this.activatedRoute.snapshot.paramMap.get('name');
    this.bookauthor = this.activatedRoute.snapshot.paramMap.get('author');
    this.book = new Book(this.bookid,this.bookname,this.bookauthor);
  }

  submitform(form:any){
    console.log('book form submitted');
    console.log(this.book);
    this.bookdao.editBook(this.book).subscribe(
      { complete: () => {console.log('addbook post completed..') }, // completeHandler
       error: (error) => { console.log(error) },    // errorHandler 
       next: (response) => { console.log('book added successfully')  }
      } )
      this.router.navigateByUrl('/listbooks')
  }

}
