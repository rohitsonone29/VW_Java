import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booksearch',
  templateUrl: './booksearch.component.html',
  styleUrls: ['./booksearch.component.css']
})
export class BooksearchComponent implements OnInit {
  book: Book;
  bookIdValue: any;
  bookNameValue: any;
  bookdao: BookdaoService;
  result: String;
  constructor(bookdao: BookdaoService) {
    this.book=new Book(1,"","");
    this.bookdao = bookdao;
    this.result = '';
  }

  ngOnInit(): void {
    
  }


  searchBookByID(form:any) {
    this.bookdao.getBookByID(this.book.bookid).subscribe(
      (data: Book) => {
        this.book = data;
        this.result = 'Book found successfully';
      }, (error) => {
        console.log(error);
        this.result = 'Book not found';
      }
    )
  }

}
