import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Book } from 'src/model/book';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {

  bookarr:Book[]
  baseurl:string;
  
  constructor(private httpclient:HttpClient) {
    this.bookarr = [];
    this.baseurl='http://localhost:5000/books'
   }

   addBook(b:Book):void
   {
      this.bookarr.push(b);
      this.httpclient.post(this.baseurl,b,{headers:new HttpHeaders({
        'Content-type':'application/json'
      })});
   }

   getAllBooks():Book[]
   {
      return  this.bookarr;
   }

}
