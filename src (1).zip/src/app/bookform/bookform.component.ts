import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit{

  book: Book;
  bookdao: BookdaoService;

  constructor(bookdao: BookdaoService) {
    this.book = new Book(1, '', '');
    this.bookdao = bookdao;

  }
  ngOnInit(): void {
    
  }

  submitform(form: any) {
    console.log('book form submitted');
    console.log(this.book);
    // this.bookdao.addBook(this.book);

    this.bookdao.addBook(this.book).subscribe(
      { complete: () => {console.log('addbook post completed..') }, // completeHandler
       error: (error) => { console.log(error) },    // errorHandler
       next: (response) => { console.log('book added successfully')  }
      } )
  }

}
