import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Book } from './model/book';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {

  baseUrl: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) {

    this.baseUrl = 'http://localhost:5000/books';
  }

  addBook(b: Book) {
    return this.httpClient.post<Book>(this.baseUrl, JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
    // this.bookarr.push(b);
  }

  // delete

  getAllBooks() {
    return this.httpClient.get<Book[]>(this.baseUrl, this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  errorHandler(httpError: HttpErrorResponse) {
    let errorMessage = '';
    if (httpError.error instanceof ErrorEvent) {
      errorMessage = httpError.error.message;
    } else {
      errorMessage = `Error Code: ${httpError.status}\nMessage: ${httpError.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httpError);
  }
}
