import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  bookarr: Book[];
  bookdao: BookdaoService;

  constructor(bookdao: BookdaoService) {
    this.bookarr = [];
    this.bookdao = bookdao;
  }

  ngOnInit(): void {
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
  }
  
}
